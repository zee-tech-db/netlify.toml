export const TELEGRAM_LINK = 'https://t.me/Anton009_io';

export const openTelegramChat = () => {
  window.open(TELEGRAM_LINK, '_blank');
};